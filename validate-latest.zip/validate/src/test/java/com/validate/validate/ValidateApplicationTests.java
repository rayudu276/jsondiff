package com.validate.validate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ValidateApplicationTests {

	@Test
	void contextLoads() {
	}

}
