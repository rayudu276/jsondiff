package com.example.jsondiff.controller;

import com.example.jsondiff.service.JsonDiffConverterService;
import com.example.jsondiff.service.JsonDiffService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

@RestController
@RequestMapping("/api/jsondiff")
public class JsonDiffController {

    @Autowired
    private JsonDiffService jsonDiffService;

    @Autowired
    private JsonDiffConverterService jsonDiffConverterService;

    private final ObjectMapper objectMapper = new ObjectMapper();

    // Hardcoded fields for comparison
    private static final Set<String> FIELDS_TO_COMPARE = new HashSet<>();

    static {
        FIELDS_TO_COMPARE.add("specfilepath");
        FIELDS_TO_COMPARE.add("documentsourcepath");
        FIELDS_TO_COMPARE.add("instances");
    }

    @PostMapping(value = "/compare", consumes = "multipart/form-data")
    public ResponseEntity<Map<String, Object>> compareJsonObjects(
            @RequestParam("oldJson") String oldJsonString,
            @RequestParam("newJson") String newJsonString) {

        try {
            JsonNode oldJson = objectMapper.readTree(oldJsonString);
            JsonNode newJson = objectMapper.readTree(newJsonString);

            Map<String, Object> differences = jsonDiffService.findDifferences(oldJson, newJson, FIELDS_TO_COMPARE);
           // Map<String, Object> converted = jsonDiffConverterService.convertDiffResult(differences);
            return ResponseEntity.ok(differences);
        } catch (IOException e) {
            return ResponseEntity.badRequest().body(Map.of("error", "Invalid JSON input"));
        }
    }
}
