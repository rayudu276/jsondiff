package com.example.jsondiff.service;

import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

@Service
public class JsonDiffService {

    // Method to compare specific fields in versions and return differences by added, modified, deleted versions
    public Map<String, Object> findDifferences(JsonNode oldJson, JsonNode newJson, Set<String> fieldsToCompare) {
        Map<String, Object> result = new HashMap<>();

        Map<String, Object> addedVersions = new HashMap<>();
        Map<String, Object> modifiedVersions = new HashMap<>();
        Map<String, Object> deletedVersions = new HashMap<>();

        // Loop through versions in oldJson and newJson and compare fields
        JsonNode oldVersions = oldJson.get("versions");
        JsonNode newVersions = newJson.get("versions");

        if (oldVersions != null && newVersions != null) {
            // Create a map to store old versions by their key (e.g., "v1", "v2")
            Map<String, JsonNode> oldVersionsMap = new HashMap<>();
            for (JsonNode version : oldVersions) {
                Iterator<String> fieldNames = version.fieldNames();
                if (fieldNames.hasNext()) {
                    String versionKey = fieldNames.next();  // "v1", "v2", etc.
                    oldVersionsMap.put(versionKey, version.get(versionKey));
                }
            }

            // Compare versions in new JSON
            for (JsonNode version : newVersions) {
                Iterator<String> fieldNames = version.fieldNames();
                if (fieldNames.hasNext()) {
                    String versionKey = fieldNames.next();  // "v1", "v2", etc.
                    JsonNode newVersionFields = version.get(versionKey);

                    if (!oldVersionsMap.containsKey(versionKey)) {
                        // This is an added version
                        addedVersions.put(versionKey, newVersionFields);
                    } else {
                        // This version exists in both old and new JSON, so check for modifications
                        JsonNode oldVersionFields = oldVersionsMap.get(versionKey);
                        Map<String, Object> modifiedFields = new HashMap<>();
                        Map<String, Object> addedFields = new HashMap<>();
                        Map<String, Object> deletedFields = new HashMap<>();
                        boolean isModified = false;
                        boolean instancesModified = false;

                        // Compare specific fields in FIELDS_TO_COMPARE
                        for (String field : fieldsToCompare) {
                            JsonNode oldField = oldVersionFields.get(field);
                            JsonNode newField = newVersionFields.get(field);

                            // Special handling for the "instances" field
                            if ("instances".equals(field)) {
                                Map<String, Object> instanceChanges = compareInstances(oldField, newField);
                                if (!instanceChanges.isEmpty()) {
                                    modifiedFields.put("instances", instanceChanges.get("modified"));
                                    addedFields.put("instances", instanceChanges.get("added"));
                                    deletedFields.put("instances", instanceChanges.get("deleted"));
                                    instancesModified = true;
                                }
                            } else if (oldField == null && newField != null) {
                                isModified = true;
                                modifiedFields.put(field, newField);
                            } else if (oldField != null && newField == null) {
                                isModified = true;
                                modifiedFields.put(field, null); // Field deleted
                            } else if (oldField != null && newField != null && !oldField.equals(newField)) {
                                isModified = true;
                                modifiedFields.put(field, newField);
                            }
                        }

                        if (isModified || instancesModified) {
                            modifiedVersions.put(versionKey, modifiedFields);
                            addedVersions.put(versionKey, addedFields);
                           deletedVersions.put(versionKey, deletedFields);
                        }

                        // Remove the version from the old map since we already processed it
                        oldVersionsMap.remove(versionKey);
                    }
                }
            }

            // Any remaining versions in the oldVersionsMap are deleted versions
            for (Map.Entry<String, JsonNode> entry : oldVersionsMap.entrySet()) {
                deletedVersions.put(entry.getKey(), entry.getValue());
            }
        }

        result.put("added", addedVersions);
        result.put("modified", modifiedVersions);
        result.put("deleted", deletedVersions);

        return result;
    }

    // Helper method to compare instances field between old and new versions
    private Map<String, Object> compareInstances(JsonNode oldInstances, JsonNode newInstances) {
        Map<String, Object> instanceChanges = new HashMap<>();

        if (oldInstances == null && newInstances != null) {
            instanceChanges.put("added", newInstances);
        } else if (oldInstances != null && newInstances == null) {
            instanceChanges.put("deleted", oldInstances);
        } else if (oldInstances != null && newInstances != null) {
            // Compare individual instances (assuming "dv1", "dv2", etc.)
            Map<String, JsonNode> oldInstancesMap = new HashMap<>();
            Map<String, JsonNode> newInstancesMap = new HashMap<>();

            for (JsonNode instance : oldInstances) {
                Iterator<String> fieldNames = instance.fieldNames();
                if (fieldNames.hasNext()) {
                    String instanceKey = fieldNames.next();
                    oldInstancesMap.put(instanceKey, instance.get(instanceKey));
                }
            }

            for (JsonNode instance : newInstances) {
                Iterator<String> fieldNames = instance.fieldNames();
                if (fieldNames.hasNext()) {
                    String instanceKey = fieldNames.next();
                    newInstancesMap.put(instanceKey, instance.get(instanceKey));
                }
            }

            Map<String, JsonNode> addedInstances = new HashMap<>();
            Map<String, JsonNode> deletedInstances = new HashMap<>();
            Map<String, JsonNode> modifiedInstances = new HashMap<>();

            // Detect added instances
            for (String key : newInstancesMap.keySet()) {
                if (!oldInstancesMap.containsKey(key)) {
                    addedInstances.put(key, newInstancesMap.get(key));
                }
            }

            // Detect deleted instances
            for (String key : oldInstancesMap.keySet()) {
                if (!newInstancesMap.containsKey(key)) {
                    deletedInstances.put(key, oldInstancesMap.get(key));
                }
            }

            // Detect modified instances
            for (String key : newInstancesMap.keySet()) {
                if (oldInstancesMap.containsKey(key) && !oldInstancesMap.get(key).equals(newInstancesMap.get(key))) {
                    modifiedInstances.put(key, newInstancesMap.get(key));
                }
            }

            if (!addedInstances.isEmpty()) {
                instanceChanges.put("added", addedInstances);
            }
            if (!deletedInstances.isEmpty()) {
                instanceChanges.put("deleted", deletedInstances);
            }
            if (!modifiedInstances.isEmpty()) {
                instanceChanges.put("modified", modifiedInstances);
            }
        }

        return instanceChanges;
    }
}
