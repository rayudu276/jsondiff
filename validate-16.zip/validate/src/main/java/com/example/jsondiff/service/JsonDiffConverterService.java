package com.example.jsondiff.service;

import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class JsonDiffConverterService {

    // Method to convert the comparison result to the required output structure
    public Map<String, Object> convertDiffResult(Map<String, Object> diffResult) {
        Map<String, Object> convertedResult = new HashMap<>();

        List<Map<String, Object>> addedList = new ArrayList<>();
        List<Map<String, Object>> modifiedList = new ArrayList<>();
        List<Map<String, Object>> deletedList = new ArrayList<>();

        // Convert added versions
        Map<String, Object> addedVersions = (Map<String, Object>) diffResult.get("added");
        for (String version : addedVersions.keySet()) {
            JsonNode versionDetails = (JsonNode) addedVersions.get(version);
            Map<String, Object> versionMap = new HashMap<>();
            versionMap.put("specfilepath", getField(versionDetails, "specfilepath"));
            versionMap.put("documentsourcepath", getField(versionDetails, "documentsourcepath"));
            versionMap.put("instances", getInstances(versionDetails));
            versionMap.put("version", version);
            addedList.add(versionMap);
        }

        // Convert modified versions
        Map<String, Object> modifiedVersions = (Map<String, Object>) diffResult.get("modified");
        for (String version : modifiedVersions.keySet()) {
            Map<String, Object> modifiedDetails = (Map<String, Object>) modifiedVersions.get(version);
            Map<String, Object> versionMap = new HashMap<>();
            versionMap.put("specfilepath", modifiedDetails.getOrDefault("specfilepath", ""));
            versionMap.put("documentsourcepath", modifiedDetails.getOrDefault("documentsourcepath", ""));
            versionMap.put("instances", modifiedDetails.getOrDefault("instances", new ArrayList<>()));
            versionMap.put("version", version);
            modifiedList.add(versionMap);
        }

        // Convert deleted versions
        Map<String, Object> deletedVersions = (Map<String, Object>) diffResult.get("deleted");
        for (String version : deletedVersions.keySet()) {
            JsonNode versionDetails = (JsonNode) deletedVersions.get(version);
            Map<String, Object> versionMap = new HashMap<>();
            versionMap.put("specfilepath", getField(versionDetails, "specfilepath"));
            versionMap.put("documentsourcepath", getField(versionDetails, "documentsourcepath"));
            versionMap.put("instances", getInstances(versionDetails));
            versionMap.put("version", version);
            deletedList.add(versionMap);
        }

        // Add lists to the final result
        convertedResult.put("CREATE", addedList);
        convertedResult.put("UPDATE", modifiedList);
        convertedResult.put("DELETE", deletedList);

        return convertedResult;
    }

    // Helper method to retrieve a field from a JsonNode
    private String getField(JsonNode versionDetails, String fieldName) {
        JsonNode field = versionDetails.get(fieldName);
        return field != null ? field.asText() : "";
    }

    // Helper method to get instances as a list from a JsonNode
    private List<Map<String, Object>> getInstances(JsonNode versionDetails) {
        List<Map<String, Object>> instancesList = new ArrayList<>();
        JsonNode instances = versionDetails.get("instances");
        if (instances != null && instances.isArray()) {
            for (JsonNode instance : instances) {
                Map<String, Object> instanceMap = new HashMap<>();
                Iterator<String> fieldNames = instance.fieldNames();
                while (fieldNames.hasNext()) {
                    String fieldName = fieldNames.next();
                    instanceMap.put(fieldName, instance.get(fieldName));
                }
                instancesList.add(instanceMap);
            }
        }
        return instancesList;
    }
}
